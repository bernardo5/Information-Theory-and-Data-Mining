function [ results_string ] = BreastCancerWisconsin_Processing( data_matrix )
%Processes the Wisconsin data about Breast Cancer
%Since all relevant features range from 1-10 no normalization is required
% matrix=data_matrix(2:)
% [coeff,score,latent] = pca(matrix)


end

